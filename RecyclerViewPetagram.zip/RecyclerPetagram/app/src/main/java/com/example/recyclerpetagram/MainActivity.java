package com.example.recyclerpetagram;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList <Mascota> mascotas;
    private RecyclerView listaMascotas;
    TextView value;
    int cont = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar miActionBar = (Toolbar) findViewById(R.id.miActionBar);
        setSupportActionBar(miActionBar);

        listaMascotas   = (RecyclerView) findViewById(R.id.rvMascotas);
        value           = (TextView) findViewById(R.id.tvPuntos);

        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        listaMascotas.setLayoutManager(llm);
        inicializaListaMascotas();
        inicializaAdaptador();
    }

    public void contador (View v){
        cont++;
        value.setText(Integer.toString(cont));
    }

    public void inicializaAdaptador(){
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,this);
        listaMascotas.setAdapter(adaptador);
    }

    public void inicializaListaMascotas(){

        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota(R.drawable.ic_chihuahua,"chihua"));
        mascotas.add(new Mascota(R.drawable.ic_doggy,"doggy"));
        mascotas.add(new Mascota(R.drawable.ic_manchas,"manchas"));
        mascotas.add(new Mascota(R.drawable.ic_orejas,"orejas"));
    }
}
